//
//  Home3Map.swift
//  GiaoDien
//
//  Created by Cuong on 12/4/18.
//  Copyright © 2018 Cuong. All rights reserved.
//

import UIKit
import MapKit

class Home3Map: UIViewController,CLLocationManagerDelegate,MKMapViewDelegate {

    @IBOutlet weak var mkview: MKMapView!
    var chuyenvido:String!
    var chuyenkinhdo:String!
    var locationManager = CLLocationManager()
    var annotationArray:[CustomAnnotation] = [CustomAnnotation]()
    
    @objc func backHome2(){
        self.navigationController?.popViewController(animated: true)
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = false
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(backHome2))
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //ho con rua 10.782742, 106.695907
        mkview.delegate = self
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
        locationManager.requestWhenInUseAuthorization()
        locationManager.startUpdatingLocation()
        //print(chuyenid!)
        self.addAnnotationsOnMapView()
        mkview.addAnnotations(self.annotationArray)
        
    }
    func addAnnotationsOnMapView(){
        // dia chi dinh vi
        let currentLocation = locationManager.location?.coordinate
        if currentLocation != nil{
        let sourceAnnotation = CustomAnnotation(coordinate: CLLocationCoordinate2D(latitude: (currentLocation?.latitude)!, longitude: (currentLocation?.longitude)!), title: "Start", subtitle: "Vi tri cua ban")
        self.annotationArray.append(sourceAnnotation)
        }
        
        
        //  10.851201, 106.772087 vi tri tao ra khi build tren macbook
//        let currentLocation = CLLocationCoordinate2D(latitude: 10.851201, longitude: 106.772087)
//
//        let sourceAnnotation = CustomAnnotation(coordinate: CLLocationCoordinate2D(latitude: currentLocation.latitude, longitude: currentLocation.longitude), title: "It", subtitle: "Vi Tri Cua ban")
//        self.annotationArray.append(sourceAnnotation)
//
        //

        let lat = Double(chuyenvido) ?? 0.0
        let longi = Double(chuyenkinhdo) ?? 0.0
//
        let destinationLocation = CLLocationCoordinate2D(latitude: lat, longitude: longi)
        
        let destinationAnnotation = CustomAnnotation(coordinate: CLLocationCoordinate2D(latitude: destinationLocation.latitude, longitude: destinationLocation.longitude), title: "End", subtitle: "Diem Den")
        
        self.annotationArray.append(destinationAnnotation)
        
        if currentLocation != nil{
        self.DrawTwoLocaltion(sourceLocation: currentLocation!, destinationLocation: destinationLocation)
        }
        
    }
    
    func DrawTwoLocaltion(sourceLocation: CLLocationCoordinate2D,destinationLocation: CLLocationCoordinate2D)
    {
        //step 1
        let sourcePlacemark = MKPlacemark(coordinate: sourceLocation, addressDictionary: nil)
        
        let destinationPlacemark = MKPlacemark(coordinate: destinationLocation, addressDictionary: nil)
        //2
        let sourceMapItem = MKMapItem(placemark: sourcePlacemark)
        let destinationMapItem = MKMapItem(placemark: destinationPlacemark)
        //3
        let directRequest = MKDirections.Request()
        
        directRequest.source = sourceMapItem
        
        directRequest.destination = destinationMapItem
        //chon phuong tien di chuyen .automobile la di bang phuong tien
        directRequest.transportType = .automobile
        
        //4
        
        let direction = MKDirections(request: directRequest)
        
        direction.calculate { (response, error) in
            if error == nil
            {
                if let route = response?.routes.first{
                    self.mkview.addOverlay(route.polyline, level: .aboveRoads)
                    
                    let rect = route.polyline.boundingMapRect
                    
                    self.mkview.setVisibleMapRect(rect, edgePadding: UIEdgeInsets(top: 40, left: 40, bottom: 20, right: 20), animated: true)
                    
                }
            }else {
                print(error?.localizedDescription as Any)
            }
        }
        
        
    }
    
    
    func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        let rederer = MKPolylineRenderer(overlay: overlay)
        rederer.strokeColor = UIColor.blue
        rederer.lineWidth = 5.0
        return rederer
}
}
