//
//  SaveTableViewController.swift
//  GiaoDien
//
//  Created by TrucRocket on 12/25/18.
//  Copyright © 2018 Cuong. All rights reserved.
//

import UIKit
import Firebase
class SaveTableViewController: UITableViewController {

    @IBOutlet var myTableViewSave: UITableView!
    var myTabbleSave = [TableSave]()
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        
    }
    override func viewWillAppear(_ animated: Bool) {
        navigationController?.navigationBar.isHidden = true
//        self.tabBarController?.tabBar.isHidden = false
        let uid = Auth.auth().currentUser?.uid
        if uid != nil{
            myTabbleSave = [TableSave]()
            LoadSaveView(uid: uid!)
            
            myTableViewSave.delegate = self
            myTableViewSave.dataSource = self
        }
    }

    // MARK: - Table view data source
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let home2 = sb.instantiateViewController(withIdentifier: "Home2") as! Home2ViewController
        home2.chuyenid = myTabbleSave[indexPath.row].idStore
       
        home2.chuyenurlhinh = myTabbleSave[indexPath.row].urlImage
        home2.chuyenNameStore = myTabbleSave[indexPath.row].ImgName
        home2.chuyenAddrStore = myTabbleSave[indexPath.row].address
        home2.chuyenContent = myTabbleSave[indexPath.row].content
        home2.chuyenvido = myTabbleSave[indexPath.row].vido
        home2.chuyenkinhdo = myTabbleSave[indexPath.row].kinhdo
        
        
        self.navigationController?.pushViewController(home2, animated: true)
    }
    override func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.red
//        let x = headerView.centerYAnchor.accessibilityActivationPoint
//        let y = headerView.centerYAnchor.accessibilityActivationPoint
//        let y = tableView.sectionHeaderHeight
//        let x = view.widthAnchor as? Int
        let label1 = UILabel(frame: CGRect(x: 150, y: 50, width: 69, height: 22))
        label1.text = "Đã Lưu"
       label1.font = UIFont.boldSystemFont(ofSize: 20)
        headerView.addSubview(label1)
        
        return headerView
    }
    
    override func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let sectionView = UIView()
//        sectionView.frame = CGRect(x: 10, y: 10, width: 50, height: 10)// For Set the Frame
        sectionView.backgroundColor = UIColor.red
        
        return sectionView
    }
    
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    
    override func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 20.0
    }
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 110
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return myTabbleSave.count
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let mycell = myTableViewSave.dequeueReusableCell(withIdentifier: "CELL", for: indexPath)
        let lblSave = mycell.viewWithTag(10) as! UILabel
        let lblStoreSave = mycell.viewWithTag(11) as! UILabel
        let imageSave = mycell.viewWithTag(12) as! UIImageView
        lblSave.text = "Bạn đã lưu quán ăn"
        lblStoreSave.text = myTabbleSave[indexPath.row].ImgName
        imageSave.image = UIImage(named: "Save")
        return mycell
    }
    func LoadSaveView(uid: String) {
        var mySave = TableSave()
        //        let url = URL(string: "http://172.20.10.14:3000/find")
        let url = URL(string: "http://172.20.10.14:3000/findUser")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        //req.setValue("Content-Type", forHTTPHeaderField: "application/x-www-form-urlencoded")
        req.httpBody = "uidfind=\(uid)".data(using: .utf8)
        let task = URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil
            {
                print("error herr...")
                print(error!)
            }
                
                
            else
            {
                //print(String(data: data!, encoding: .utf8)!)
                if let content = data
                {
                    do
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        //print("-----------")
                        //print(myJson)
                        if let jsonData = myJson as? [String:Any]
                        {
                            if let myResult = jsonData["result"] as? [String:Any]
                            {
                                if let myMoreCont = myResult["SaveStore"] as? [[String:Any]]
                                {
                                    for value in myMoreCont
                                    {
                                        if let idstore = value["idStore"] as? String
                                        {
                                            mySave.idStore = idstore
                                        }
                                        if let urlImage = value["urlImage"] as? String{
                                            mySave.urlImage = urlImage
                                        }
                                        if let ImgName = value["ImgName"] as? String{
                                            mySave.ImgName = ImgName
                                        }
                                        if let address = value["address"] as? String{
                                            mySave.address = address
                                        }
                                        if let kinhdo = value["kinhdo"] as? String{
                                            mySave.kinhdo = kinhdo
                                        }
                                        if let vido = value["vido"] as? String{
                                            mySave.vido = vido
                                        }
                                        if let contents = value["contents"] as? String{
                                            mySave.content = contents
                                        }
                                        self.myTabbleSave.append(mySave)
                                    }//end for loot
                                    //                                    dump(self.myTableMenu)
                                    DispatchQueue.main.async {
                                        self.myTableViewSave.reloadData()
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                        
                    }
                }
                
            }
        }
        task.resume()
    }//end Load

    

}
