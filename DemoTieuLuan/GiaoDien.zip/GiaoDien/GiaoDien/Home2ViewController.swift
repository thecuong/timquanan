//
//  Home2ViewController.swift
//  GiaoDien
//
//  Created by Cuong on 12/3/18.
//  Copyright © 2018 Cuong. All rights reserved.
//

import UIKit
import MapKit
import Firebase

class Home2ViewController: UIViewController,MKMapViewDelegate,UITableViewDelegate,UITableViewDataSource,CLLocationManagerDelegate {
    @IBOutlet weak var tableviewMenu: UITableView!
    @IBOutlet weak var lblNameStore: UILabel!
    @IBOutlet weak var imgStoreView: UIImageView!
    @IBOutlet weak var tableViewComment: UITableView!
    
    var checkBook = 10
    @IBOutlet weak var Addres: UILabel!
    //next viewcontroll3
    @IBAction func NextMapView(_ sender: Any) {
        let sb = UIStoryboard(name: "Main", bundle: nil)
        let home3 = sb.instantiateViewController(withIdentifier: "MapView") as! Home3Map
    
        home3.chuyenvido = chuyenvido
        home3.chuyenkinhdo = chuyenkinhdo
        
        self.navigationController?.pushViewController(home3, animated: true)
        
    }
    let commentTextfield: UITextField = {
        let tf = UITextField()
        tf.placeholder = "Viết nhận xét...."
//        commentTextfield.borderStyle = .roundedRect
        tf.borderStyle = .roundedRect
        return tf
    }()
    
    @IBOutlet weak var lblContentStore: UILabel!
    var chuyenid:String!
    var chuyenurlhinh:String!
    var chuyenNameStore:String!
    var chuyenAddrStore:String!
    var chuyenContent:String!
    var chuyenvido:String!
    var chuyenkinhdo:String!
    var locationManager = CLLocationManager()
    var annotationArray:[CustomAnnotation] = [CustomAnnotation]()
    
    var myTableMenu = [NewMenu]()
    var myTableComment = [Comments]()
    var reversedTableComment = [Comments]()
    
    @objc func saveview(){
        let uid = Auth.auth().currentUser?.uid
        let url = URL(string: "http://172.20.10.14:3000/addSaveUsers")
        var req = URLRequest(url: url!)
        let json:[String: Any] = ["iduser" : uid!,
                                  "IDStore" : chuyenid!,
                                  "Urlstore" : chuyenurlhinh!,
                                  "NameStore" : self.chuyenNameStore!,
                                  "AddrStore" : self.chuyenAddrStore!,
                                  "kinhdo" : self.chuyenkinhdo!,
                                  "vido" : self.chuyenvido!,
                                  "ConStore" : self.chuyenContent! ]
        let jsondata = try? JSONSerialization.data(withJSONObject: json)
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpMethod = "POST"
        req.httpBody = jsondata
        URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
            print(data!)
        }).resume()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Bỏ Lưu", style: .plain, target: self, action: #selector(Didsaveview))

    }
    override func viewWillAppear(_ animated: Bool) {
        loadMenu()
        loadComment()
    }
    
    func checkSave(uid: String, idSave: String) -> Int {
        
        let url = URL(string: "http://172.20.10.14:3000/check")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = "uidUser=\(uid)&idSave=\(idSave)".data(using: .utf8)
        
        let task = URLSession.shared.dataTask(with: req, completionHandler:{ (data, res, err) in
            print(String(data: data!, encoding: .utf8)!)
            let check = (String(data: data!, encoding: .utf8)!)
            if check == "1"{
                self.checkBook = 1
            }
            else{
                self.checkBook = 0
                //                print(self.checkSave!)
            }
        })
        task.resume()
        print(self.checkBook)
        print("-------")
        return checkBook
        
    }
    @objc func Didsaveview(){
        let uid = Auth.auth().currentUser?.uid
        let url = URL(string: "http://172.20.10.14:3000/deleteSave")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"

        let postString = "idStore=\(chuyenid!)&uid=\(uid!)"
        req.httpBody = postString.data(using: .utf8)
        URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
            print(data!)
        }).resume()
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Lưu", style: .plain, target: self, action: #selector(saveview))
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let uid = Auth.auth().currentUser?.uid
        if Auth.auth().currentUser?.uid != nil{
            if checkSave(uid: uid!, idSave: chuyenid!) == 0
            {
                navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Lưu", style: .plain, target: self, action: #selector(saveview))
            }
            else{
                navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Bỏ Lưu", style: .plain, target: self, action: #selector(Didsaveview))
            }
        }
        
        
        
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.tabBarController?.tabBar.isHidden = false
        navigationController?.navigationBar.isHidden = true
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBarController?.tabBar.isHidden = true
        navigationController?.navigationBar.isHidden = false
        let uid = Auth.auth().currentUser?.uid
        if Auth.auth().currentUser?.uid != nil{
//            checkSave(uid: uid!, idSave: chuyenid!)
            if checkSave(uid: uid!, idSave: chuyenid!) == 0
            {
                navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Lưu", style: .plain, target: self, action: #selector(saveview))
            }
            else{
                navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Bỏ Lưu", style: .plain, target: self, action: #selector(Didsaveview))
            }
            
        }
      
        //load imgStore
        let url:URL = URL(string: chuyenurlhinh!)!
        do
        {
            let dulieu:Data = try Data(contentsOf: url)
            imgStoreView.image = UIImage(data: dulieu)
        }
        catch
        {
            
        }
        //end load ImgStore
        lblNameStore.text = chuyenNameStore
        lblContentStore.text = chuyenContent
        Addres.text = chuyenAddrStore
        
       
    }
    @objc func sendComment()
    {
        if commentTextfield.text == "" {
            self.ThongBao(messe: "Bạn phải viết nhật xét")
//            return
        }
        else
        {
            var ref: DatabaseReference!
            ref = Database.database().reference()
            let userID = Auth.auth().currentUser?.uid
            ref.child("users").child(userID!).observeSingleEvent(of: .value, with: { (snapshot) in
                // Get user value
                let value = snapshot.value as? NSDictionary
                let name = value?["name"] as? String ?? ""
                let profileImage = value?["profileImage"] as? String ?? ""
                let url = URL(string: "http://172.20.10.14:3000/addComment")
                let json:[String: Any] = ["idupdata": self.chuyenid!,
                                          "uid": userID!,
                                          "content": self.commentTextfield.text!,
                                          "name" : name,
                                          "imgprofile" : profileImage
                                        ]
                
                let jsondata = try? JSONSerialization.data(withJSONObject: json)
                
                var req = URLRequest(url: url!)
                req.setValue("application/json", forHTTPHeaderField: "Content-Type")
                req.httpMethod = "POST"
                req.httpBody = jsondata
                URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
                    print(String(data: data!, encoding: .utf8)!)
                }).resume()
                self.commentTextfield.text = ""
                DispatchQueue.main.async {
                    self.reversedTableComment = [Comments]()
                    self.loadComment()
                    self.tableViewComment.reloadData()
                }
            }) { (error) in
                print(error.localizedDescription)
            }
        }
        self.view.endEditing(true)
    }
    func UpdataComment(content: String, UID: String, IDStore: String) {
        let url = URL(string: "http://172.20.10.14:3000/editComment")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = "idstore=\(IDStore)&uid=\(UID)&cmt=\(content)".data(using: .utf8)
        URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
            print(String(data: data!, encoding: .utf8)!)
            DispatchQueue.main.async {
                self.reversedTableComment = [Comments]()
                self.loadComment()
                self.tableViewComment.reloadData()
            }
        }).resume()
    }
    func RemoveComment(IDStore: String, IDCmt: String) {
        let url = URL(string: "http://172.20.10.14:3000/deleteComment")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        req.setValue("application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")
        req.httpBody = "IDStore=\(IDStore)&idCmt=\(IDCmt)".data(using: .utf8)
        URLSession.shared.dataTask(with: req, completionHandler: { (data, res, err) in
            print(String(data: data!, encoding: .utf8)!)
            DispatchQueue.main.async {
                self.reversedTableComment = [Comments]()
                self.loadComment()
                self.tableViewComment.reloadData()
            }
        }).resume()
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if tableView == tableViewComment {
            if let uid = Auth.auth().currentUser?.uid {
                if uid == myTableComment[indexPath.row].uid {
                    let alert:UIAlertController = UIAlertController(title: "Comment", message: "Chỉnh sử bình luận của bạn", preferredStyle: .alert)
                    alert.addTextField { (txtcontent) in
                        txtcontent.text = self.myTableComment[indexPath.row].content
                    }
                    let btnLuu:UIAlertAction = UIAlertAction(title: "Lưu", style: .default) { (btnLuu) in
                         let content:String = alert.textFields![0].text!
                        self.UpdataComment(content: content, UID: uid, IDStore: self.chuyenid)
                    }
                    let btnCancel:UIAlertAction = UIAlertAction(title: "Huỷ", style: .cancel) { (btnCancel) in
                    }
                    let btnRemove:UIAlertAction = UIAlertAction(title: "Xóa", style: .destructive) { (btnRemove) in
                        self.RemoveComment(IDStore: self.chuyenid!, IDCmt: self.myTableComment[indexPath.row].id)
                    }
                    
                    alert.addAction(btnLuu)
                    alert.addAction(btnRemove)
                    alert.addAction(btnCancel)
                    
                    present(alert, animated: true, completion: nil)
                }
            }
        }
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if tableView == self.tableviewMenu {
            return 30
        } else {
            return 60
        }
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        var headerView = UITextField()
        if tableView == self.tableviewMenu
        {
           let headerView1 = UITextField()

            headerView1.placeholder = "Thực Đơn"
            headerView1.isEnabled = false
            headerView1.backgroundColor = UIColor.lightGray
            headerView = headerView1
        }
        else
        {
            
            if Auth.auth().currentUser?.uid != nil
            {
                let overlayButton = UIButton( frame: CGRect(x: 0, y: 0, width: 50, height: 50))
                overlayButton.setImage(UIImage(named: "send"), for: .normal)
                overlayButton.addTarget(self, action: #selector(sendComment), for: .touchUpInside)
                commentTextfield.rightViewMode = UITextField.ViewMode.always
                commentTextfield.rightView = overlayButton
                headerView = commentTextfield
            }
            else
            {
                let headerView2 = UITextField()
                headerView2.placeholder = "Bạn phải đăng nhập để nhận xét"
                headerView2.isEnabled = false
                headerView2.backgroundColor = UIColor.lightGray
                headerView = headerView2
            }
            
           
        }
        return headerView
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView?{
        let footerView = UIView()
        footerView.backgroundColor = UIColor.darkGray
        return footerView
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == self.tableviewMenu
        {
            return myTableMenu.count
        }
        if tableView == self.tableViewComment
        {
            return myTableComment.count
        }
        else
        {
            return 0
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cellToReturn = UITableViewCell()
        if tableView == self.tableviewMenu
        {
            let myCell = tableviewMenu.dequeueReusableCell(withIdentifier: "cell2", for: indexPath)
            let myImgV = myCell.viewWithTag(10) as! UIImageView
            let myLbName = myCell.viewWithTag(11) as! UILabel
            let myLblPrice = myCell.viewWithTag(12) as! UILabel
            
            myLbName.text = myTableMenu[indexPath.row].namefood
            myLblPrice.text = myTableMenu[indexPath.row].price
            
            let myURl = myTableMenu[indexPath.row].urlimg
            loadImg(url: myURl, to: myImgV)
            cellToReturn = myCell
            return myCell
        }
        if tableView == self.tableViewComment
        {
            let myCell = tableViewComment.dequeueReusableCell(withIdentifier: "cell3", for: indexPath)
            myCell.textLabel?.text = myTableComment[indexPath.row].name
            myCell.detailTextLabel?.text = myTableComment[indexPath.row].content
            let myUrl = myTableComment[indexPath.row].imgprofile
            loadImg(url: myUrl, to: (myCell.imageView)!)
            cellToReturn = myCell
            return myCell
        }
       return cellToReturn
        
        
    }
    func loadImg(url: String, to imageview: UIImageView) {
        let url = URL(string: url)
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            guard let data = data else
            {
                return
            }
            DispatchQueue.main.async {
                imageview.image = UIImage(data: data)
            }
            }.resume()
        
    }
    

    func loadMenu() {
        var myMenu = NewMenu()
//        let url = URL(string: "http://172.20.10.14:3000/find")
        let url = URL(string: "http://172.20.10.14:3000/find")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        //req.setValue("Content-Type", forHTTPHeaderField: "application/x-www-form-urlencoded")
        req.httpBody = "idfind=\(chuyenid!)".data(using: .utf8)
        let task = URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil
            {
                print("error herr...")
                print(error!)
            }
                
                
            else
            {
                //print(String(data: data!, encoding: .utf8)!)
                if let content = data
                {
                    do
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        //print("-----------")
                        //print(myJson)
                        if let jsonData = myJson as? [String:Any]
                        {
                            if let myResult = jsonData["result"] as? [String:Any]
                            {
                                if let myMoreCont = myResult["MoreContents"] as? [[String:Any]]
                                {
                                    for value in myMoreCont
                                    {
                                        if let idFood = value["_id"] as? String
                                        {
                                            myMenu.id = idFood
                                        }
                                        if let urlFood = value["ImgFood"] as? String
                                        {
                                            //print(urlFood)
                                            myMenu.urlimg = urlFood
                                        }
                                        if let namefood = value["ImgNameFood"] as? String
                                        {
                                            myMenu.namefood = namefood
                                        }
                                        if let price = value["Price"] as? String
                                        {
                                            myMenu.price = price
                                        }
                                        self.myTableMenu.append(myMenu)
                                    }//end for loot
//                                    dump(self.myTableMenu)
                                    DispatchQueue.main.async {
                                        self.tableviewMenu.reloadData()
                                    }
                                }
                            }
                        }
                    }
                    catch
                    {
                        
                    }
                }
                
            }
        }
        task.resume()
    }//end
   

    
    func loadUser(uid: String) {
        
        //        let url = URL(string: "http://172.20.10.14:3000/find")
        let url = URL(string: "http://172.20.10.14:3000/findUser")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        //req.setValue("Content-Type", forHTTPHeaderField: "application/x-www-form-urlencoded")
        req.httpBody = "uidfind=\(uid)".data(using: .utf8)
        let task = URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil
            {
                print("error herr...")
                print(error!)
            }
                
                
            else
            {
                //                print(String(data: data!, encoding: .utf8)!)
                if let content = data
                {
                    do
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        //print("-----------")
                        //                        print(myJson)
                        if let jsonData = myJson as? [String:Any]
                        {
                            if let myResult = jsonData["result"] as? [String:Any]
                            {
                                if let idu = myResult["_id"] as? String
                                {
//                                    self.UserMongo.id = idu
                                    print(idu)
                                }
                                if let idFirebase = myResult["uid"] as? String{
//                                    self.UserMongo.uid = idFirebase
                                    print(idFirebase)
                                }
                                
//                                dump(self.UserMongo)
                                
                            }
                        }
                    }
                    catch
                    {
                        
                    }
                }
                
            }
        }
        task.resume()
    }//end loadUserID
//    
    func loadComment() {
        var myComment = Comments()
        //        let url = URL(string: "http://172.20.10.14:3000/find")
        let url = URL(string: "http://172.20.10.14:3000/find")
        var req = URLRequest(url: url!)
        req.httpMethod = "POST"
        //req.setValue("Content-Type", forHTTPHeaderField: "application/x-www-form-urlencoded")
        req.httpBody = "idfind=\(chuyenid!)".data(using: .utf8)
        let task = URLSession.shared.dataTask(with: req) { (data, response, error) in
            if error != nil
            {
                print("error herr...")
                print(error!)
            }
                
                
            else
            {
                //print(String(data: data!, encoding: .utf8)!)
                if let content = data
                {
                    do
                    {
                        let myJson = try JSONSerialization.jsonObject(with: content, options: .mutableContainers)
                        //print("-----------")
                        //print(myJson)
                        if let jsonData = myJson as? [String:Any]
                        {
                            if let myResult = jsonData["result"] as? [String:Any]
                            {
                                if let myMoreCont = myResult["Comments"] as? [[String:Any]]
                                {
                                    for value in myMoreCont
                                    {
                                        if let id = value["_id"] as? String {
                                            myComment.id = id
                                        }
                                        if let uid = value["uid"] as? String
                                        {
                                            myComment.uid = uid
                                        }
                                        if let content = value["content"] as? String
                                        {
                                            //print(urlFood)
                                            myComment.content = content
                                        }
                                        if let name = value["name"] as? String
                                        {
                                            myComment.name = name
                                        }
                                        if let imgprofile = value["imgprofile"] as? String
                                        {
                                            myComment.imgprofile = imgprofile
                                        }
                                        
                                        self.reversedTableComment.append(myComment)
                                        }
                                    }//end for loot
                                    self.myTableComment = [Comments]()
                                    for arrayIndex in 0..<self.reversedTableComment.count {
                                        self.myTableComment.append(self.reversedTableComment[(self.reversedTableComment.count - 1) - arrayIndex])
                                    }
                                DispatchQueue.main.async {
                                    self.tableViewComment.reloadData()
                                }
                            }
                        }
                    }
                    catch
                    {
                        
                    }
                }
                
            }
        }
        task.resume()
    }//end
    
    /*
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let currentLocation = locations.last
        let region = MKCoordinateRegion(center: (currentLocation?.coordinate)!, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        mkMapview.setRegion(region, animated: true)
    }*/
    
    func ThongBao(messe:String) {
        let alert:UIAlertController = UIAlertController(title: "Thông báo", message: messe, preferredStyle: .alert)
        let btnOK:UIAlertAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(btnOK)
        present(alert, animated: true, completion: nil)
    }
}//end class

